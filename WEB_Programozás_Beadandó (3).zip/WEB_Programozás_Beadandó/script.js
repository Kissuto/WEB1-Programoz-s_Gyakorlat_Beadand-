document.addEventListener("DOMContentLoaded", function () {
    // 1. Kapcsolatfelvételi űrlap ellenőrzése
    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", function (e) {
            let valid = true;

            // Mezők lekérése
            const nev = document.getElementById("nev");
            const email = document.getElementById("email");
            const szoveg = document.getElementById("szoveg");

            // Hibaüzenet helyek
            const nevError = document.getElementById("nevError");
            const emailError = document.getElementById("emailError");
            const szovegError = document.getElementById("szovegError");

            // Alaphelyzetbe állítás
            [nevError, emailError, szovegError].forEach(el => el.textContent = "");

            // Név ellenőrzése
            if (nev.value.trim().length < 3) {
                nevError.textContent = "A névnek legalább 3 karakternek kell lennie!";
                valid = false;
            }

            // Email ellenőrzése (Regex)
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email.value)) {
                emailError.textContent = "Kérjük, érvényes e-mail címet adjon meg!";
                valid = false;
            }

            // Üzenet ellenőrzése
            if (szoveg.value.trim().length < 10) {
                szovegError.textContent = "Az üzenetnek legalább 10 karakternek kell lennie!";
                valid = false;
            }

            if (!valid) {
                e.preventDefault(); // Megállítja a küldést, ha hiba van
            }
        });
    }

    // 2. Regisztrációs űrlap ellenőrzése (ha a belepes.tpl.php-ben van)
    const regForm = document.querySelector("form[action='regisztral']");
    if (regForm) {
        regForm.addEventListener("submit", function (e) {
            const inputs = regForm.querySelectorAll("input[type='text'], input[type='password']");
            let empty = false;

            inputs.forEach(input => {
                if (input.value.trim() === "") {
                    input.style.borderColor = "red";
                    empty = true;
                } else {
                    input.style.borderColor = "#ccc";
                }
            });

            if (empty) {
                e.preventDefault();
                alert("Kérjük, töltsön ki minden mezőt a regisztrációhoz!");
            }
        });
    }
});