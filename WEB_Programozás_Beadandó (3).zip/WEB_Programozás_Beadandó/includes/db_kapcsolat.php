<?php
// includes/db_kapcsolat.php
$host = 'localhost';
$dbname = 'adatbazis_neve'; // Ide írd az adatbázisod nevét
$user = 'root';
$pass = '';

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Hiba az adatbázishoz való csatlakozáskor: " . $e->getMessage());
}
?>