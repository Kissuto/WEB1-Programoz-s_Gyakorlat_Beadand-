<section class="content-block">
    <div class="crud-header">
        <h2>Adatbázis kezelése (CRUD)</h2>
        <a href="index.php?oldal=crud_uj" class="btn btn-success">Új adat hozzáadása</a>
    </div>
    
    <table class="styled-table">
        <thead>
            <tr>
                <th>Azonosító</th>
                <th>Név</th>
                <th>Érték</th>
                <th>Műveletek</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Példa bejegyzés</td>
                <td>1250 Ft</td>
                <td>
                    <a href="#" class="btn btn-edit">Szerkesztés</a>
                    <a href="#" class="btn btn-delete">Törlés</a>
                </td>
            </tr>
        </tbody>
    </table>
</section>