<?php
include('./includes/config.inc.php');

// A lekérés tisztítása: csak az oldal nevét vesszük figyelembe
$oldal = key($_GET); 

if (empty($oldal) || $oldal == "/") {
    // Ha nincs paraméter, a konfigurációban '/' kulccsal jelölt főoldalt töltjük be
    $keres = $oldalak['/'];
} elseif (isset($oldalak[$oldal]) && file_exists("./templates/pages/{$oldalak[$oldal]['fajl']}.tpl.php")) {
    // Ha létezik az oldal a configban és a fájlrendszerben is
    $keres = $oldalak[$oldal];
} else { 
    // Ha nem található (404)
    $keres = $hiba_oldal;
    header("HTTP/1.0 404 Not Found");
}

include('./templates/index.tpl.php'); 
?>