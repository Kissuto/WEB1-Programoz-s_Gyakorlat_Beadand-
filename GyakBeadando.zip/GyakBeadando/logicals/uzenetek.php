<?php
try {
    $dbh = new PDO('mysql:host=localhost;dbname=gyakorlat7;charset=utf8', 'root', '',
                    array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
    $sql = "SELECT * FROM uzenetek ORDER BY datum DESC";
    $sth = $dbh->query($sql);
    $uzenetek_lista = $sth->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $hiba = $e->getMessage();
}
?>