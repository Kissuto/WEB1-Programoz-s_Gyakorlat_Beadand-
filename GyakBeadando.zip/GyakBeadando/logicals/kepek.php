<?php
$mappa = './images/';
$uzenet = array();

// --- 1. TÖRLÉS LOGIKA ---
if (isset($_SESSION['login']) && isset($_GET['torles'])) {
    $fajlNev = basename($_GET['torles']); // Biztonság: csak a fájlnevet vegye figyelembe
    $utvonal = $mappa . $fajlNev;

    if (file_exists($utvonal)) {
        if (unlink($utvonal)) {
            $uzenet[] = "A kép ($fajlNev) sikeresen törölve!";
        } else {
            $uzenet[] = "Hiba történt a törlés során!";
        }
    }
}

// --- 2. FELTÖLTÉS LOGIKA ---
if (isset($_SESSION['login']) && isset($_FILES['sajatkep']) && $_FILES['sajatkep']['error'] == 0) {
    $tipusok = array('image/jpeg', 'image/png', 'image/gif');
    $fajl = $_FILES['sajatkep'];

    if (in_array($fajl['type'], $tipusok)) {
        if ($fajl['size'] < 5 * 1024 * 1024) {
            // Egyedi név generálása, hogy ne írja felül a régit
            $ujNev = time() . '_' . basename($fajl['name']);
            $cel_utvonal = $mappa . $ujNev;
            
            if (move_uploaded_file($fajl['tmp_name'], $cel_utvonal)) {
                $uzenet[] = "Sikeres feltöltés: " . basename($fajl['name']);
            } else {
                $uzenet[] = "Hiba történt a fájl mentésekor!";
            }
        } else {
            $uzenet[] = "A fájl túl nagy! Max 5MB engedélyezett.";
        }
    } else {
        $uzenet[] = "Nem megfelelő fájlformátum! Csak JPG, PNG és GIF engedélyezett.";
    }
}
?>