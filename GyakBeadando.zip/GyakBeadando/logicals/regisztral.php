<?php
if(isset($_POST['felhasznalo']) && isset($_POST['jelszo']) && isset($_POST['vezeteknev']) && isset($_POST['utonev'])) {
    try {
        $dbh = new PDO('mysql:host=localhost;dbname=gyakorlat7;charset=utf8', 'root', '',
                        array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
        
        // Ellenőrizzük, létezik-e a név
        $sqlSelect = "select id from felhasznalok where bejelentkezes = :bejelentkezes";
        $sth = $dbh->prepare($sqlSelect);
        $sth->execute(array(':bejelentkezes' => $_POST['felhasznalo']));

        if($row = $sth->fetch(PDO::FETCH_ASSOC)) {
            $uzenet = "A felhasználói név már foglalt!";
            $ujra = true;
        } else {
            // SHA1 titkosítás a régi PHP verziókhoz
            $sqlInsert = "insert into felhasznalok(csaladi_nev, uto_nev, bejelentkezes, jelszo)
                          values(:csaladinev, :utonev, :bejelentkezes, :jelszo)";
            $stmt = $dbh->prepare($sqlInsert); 
            $stmt->execute(array(
                ':csaladinev' => $_POST['vezeteknev'], 
                ':utonev' => $_POST['utonev'],
                ':bejelentkezes' => $_POST['felhasznalo'], 
                ':jelszo' => sha1($_POST['jelszo']) 
            )); 

            if($stmt->rowCount()) {
                $newid = $dbh->lastInsertId();
                $uzenet = "Sikeres regisztráció! Azonosító: {$newid}";                     
                $ujra = false;
            } else {
                $uzenet = "Hiba a mentés során.";
                $ujra = true;
            }
        }
    } catch (PDOException $e) {
        $uzenet = "Adatbázis hiba: " . $e->getMessage();
        $ujra = true;
    }
}
?>