<?php
if(isset($_POST['felhasznalo']) && isset($_POST['jelszo'])) {
    try {
        $dbh = new PDO('mysql:host=localhost;dbname=gyakorlat7;charset=utf8', 'root', '',
                        array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
        
        $sqlSelect = "select id, csaladi_nev, uto_nev, jelszo from felhasznalok where bejelentkezes = :bejelentkezes";
        $sth = $dbh->prepare($sqlSelect);
        $sth->execute(array(':bejelentkezes' => $_POST['felhasznalo']));
        $row = $sth->fetch(PDO::FETCH_ASSOC);

        // Ellenőrzés sha1-el
        if($row && sha1($_POST['jelszo']) == $row['jelszo']) {
            $_SESSION['csn'] = $row['csaladi_nev']; 
            $_SESSION['un'] = $row['uto_nev']; 
            $_SESSION['login'] = $_POST['felhasznalo'];
            
            // SIKER: Átirányítás a főoldalra, hogy ne ragadjunk a formnál
            header("Location: index.php");
            exit(); 
        } else {
            $errormessage = "Hibás felhasználónév vagy jelszó!";
        }
    } catch (PDOException $e) {
        $errormessage = "Hiba: " . $e->getMessage();
    }
}
?>