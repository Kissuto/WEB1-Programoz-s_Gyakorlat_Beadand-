<?php
$uzenet_visszajelzes = "";

if (isset($_POST['nev']) && isset($_POST['email']) && isset($_POST['szoveg'])) {
    $nev = trim($_POST['nev']);
    $email = trim($_POST['email']);
    $szoveg = trim($_POST['szoveg']);

    // Szerveroldali ellenőrzés
    if (empty($nev) || !filter_var($email, FILTER_VALIDATE_EMAIL) || empty($szoveg)) {
        $uzenet_visszajelzes = "Hiba: Hiányzó vagy hibás adatok!";
    } else {
        try {
            $dbh = new PDO('mysql:host=localhost;dbname=gyakorlat7;charset=utf8', 'root', '',
                            array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
        
        // ... a try blokkon belül:
            $sqlInsert = "INSERT INTO uzenetek (bejelentkezes, nev, email, szoveg) VALUES (:bejelentkezes, :nev, :email, :szoveg)";
            $stmt = $dbh->prepare($sqlInsert);
            $stmt->execute(array(
                ':bejelentkezes' => isset($_SESSION['login']) ? $_SESSION['login'] : 'Vendég',
                ':nev' => $nev,
                ':email' => $email,
                ':szoveg' => $szoveg));
            
            $uzenet_visszajelzes = "Köszönjük! Az üzenetet rögzítettük.";
            // Itt elmentjük a beküldött adatokat a megjelenítéshez
            $bekuldott_adatok = array('nev' => $nev, 'email' => $email, 'szoveg' => $szoveg);
        } catch (PDOException $e) {
            $uzenet_visszajelzes = "Adatbázis hiba: " . $e->getMessage();
        }
    }
}
?>