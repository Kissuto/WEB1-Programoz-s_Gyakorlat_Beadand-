CREATE DATABASE IF NOT EXISTS `gyakorlat7`
CHARACTER SET utf8 COLLATE utf8_general_ci;

USE `gyakorlat7`;

DROP TABLE IF EXISTS `felhasznalok`;

CREATE TABLE `felhasznalok` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `csaladi_nev` varchar(45) NOT NULL default '',
  `uto_nev` varchar(45) NOT NULL default '',
  `bejelentkezes` varchar(50) NOT NULL default '',
  `jelszo` varchar(255) NOT NULL default '', -- Megnövelve 255-re a hash miatt
  PRIMARY KEY  (`id`),
  UNIQUE KEY `bejelentkezes_UNIQUE` (`bejelentkezes`) -- Megakadályozza a névütközést DB szinten is
) ENGINE = MYISAM CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Figyelem: A PHP-d password_verify-t használ, 
-- így ezek a régi sha1-es tesztadatok nem fognak tudni belépni!
-- A regisztráción keresztül létrehozott új felhasználók viszont tökéletesek lesznek.
INSERT INTO `felhasznalok` (`csaladi_nev`,`uto_nev`,`bejelentkezes`,`jelszo`) VALUES 
 ('Teszt', 'Elek', 'teszt1', 'peldajelszo');

 ALTER TABLE `felhasznalok` MODIFY `jelszo` VARCHAR(255) NOT NULL;

 CREATE TABLE uzenetek (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nev VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    szoveg TEXT NOT NULL,
    datum DATETIME DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE uzenetek ADD COLUMN bejelentkezes VARCHAR(50) DEFAULT 'Vendég' AFTER id;