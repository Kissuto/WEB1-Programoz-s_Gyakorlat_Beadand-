<?php
session_start();
include('./includes/config.inc.php');

$oldal = key($_GET); 

if (empty($oldal) || $oldal == "/") {
    $keres = $oldalak['/'];
} elseif (isset($oldalak[$oldal]) && file_exists("./templates/pages/{$oldalak[$oldal]['fajl']}.tpl.php")) {
    $keres = $oldalak[$oldal];
} else { 
    $keres = $hiba_oldal;
    header("HTTP/1.0 404 Not Found");
}

// 1. ELŐSZÖR A BEJELENTKEZÉS LOGIKÁJA FUSSON LE
$logika = "./logicals/{$keres['fajl']}.php";
if (file_exists($logika)) {
    include($logika); 
}

// 2. CSAK EZUTÁN TÖLTJÜK BE A SABLONT
include('./templates/index.tpl.php'); 
?>