<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title><?= $ablakcim['cim'] . ( (isset($keres['szoveg'])) ? (' - ' . $keres['szoveg']) : '' ) ?></title>
    <link rel="stylesheet" href="styles/stilus.css" type="text/css">
</head>
<body>
    <div id="wrapper">
       <header>
    <div class="user-status">
        <?php if(isset($_SESSION['login'])): ?>
            <p>Bejelentkezett: <strong><?= $_SESSION['csn']." ".$_SESSION['un'] ?></strong> (<?= $_SESSION['login'] ?>)</p>
        <?php else: ?>
            <p>Bejelentkezett: Vendég</p>
        <?php endif; ?>
    </div>
    
    <nav>
        <ul class="nav-menu">
            <?php foreach ($oldalak as $url => $oldal) { ?>
                <?php if (!isset($_SESSION['login']) && $oldal['menun'][0] || isset($_SESSION['login']) && $oldal['menun'][1]) { ?>
                    <li<?= (($keres == $oldal) ? ' class="active"' : '') ?>>
                        <a href="<?= ($url == '/') ? '.' : ('index.php?' . $url) ?>"><?= $oldal['szoveg'] ?></a>
                    </li>
                <?php } ?>
            <?php } ?>
        </ul>
    </nav>
</header>

        <main>
            <?php include("./templates/pages/{$keres['fajl']}.tpl.php"); ?>
        </main>

        <footer>
            <p>&copy; <?= date("Y") ?> - <?= $lablec['ceg'] ?></p>
        </footer>
    </div>
</body>
</html>