<div class="auth-container">
    <div class="auth-card">
        <h2>Regisztráció</h2>
        <p style="color: var(--secondary-color); text-align: center; margin-bottom: 20px;">
            Hozza létre saját fiókját egyszerűen!
        </p>
        
        <form action="index.php?regisztral" method="post">
            <fieldset style="border:none;">
                <div class="form-group">
                    <input type="text" name="vezeteknev" placeholder="Vezetéknév" required>
                </div>
                <div class="form-group">
                    <input type="text" name="utonev" placeholder="Utónév" required>
                </div>
                <div class="form-group">
                    <input type="text" name="felhasznalo" placeholder="Választott felhasználónév" required>
                </div>
                <div class="form-group">
                    <input type="password" name="jelszo" placeholder="Jelszó" required>
                </div>
                <input type="submit" name="regisztracio" value="Fiók létrehozása" class="btn">
            </fieldset>
        </form>
        
        <div style="margin-top: 20px; text-align: center;">
            <a href="index.php?belepes" style="color: var(--secondary-color); text-decoration: none; font-size: 0.9rem;">
                ← Vissza a bejelentkezéshez
            </a>
        </div>
    </div>
</div>