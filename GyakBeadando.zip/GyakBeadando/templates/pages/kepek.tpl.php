<?php
$mappa = './images/';
if (!file_exists($mappa)) {
    mkdir($mappa, 0777, true);
}

$kepek = glob($mappa . "*.{jpg,jpeg,png,gif,JPG,JPEG,PNG,GIF}", GLOB_BRACE);
if ($kepek) {
    array_multisort(array_map('filemtime', $kepek), SORT_DESC, $kepek);
}
?>

<section class="gallery-container">
    <div class="gallery-header">
        <h2>Galéria</h2>
        <p>Fedezd fel és bővítsd a közös gyűjteményt!</p>
    </div>

    <?php if (isset($_SESSION['login'])): ?>
        <div class="pro-upload-card">
            <form action="index.php?kepek" method="post" enctype="multipart/form-data">
                <div class="upload-zone">
                    <div class="icon-circle">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    </div>
                    <h3>Kép feltöltése</h3>
                    <p>Kattints a fájl kiválasztásához</p>
                    <input type="file" name="sajatkep" id="fileInput" required accept="image/*" onchange="updateFileName()">
                    <div id="file-name-display" class="file-name">Nincs fájl kiválasztva</div>
                </div>
                <button type="submit" class="upload-btn">Feltöltés indítása</button>
            </form>
            <div class="upload-info">
                <span>Max. 5MB</span>
                <span>JPG, PNG, GIF</span>
            </div>
        </div>
    <?php else: ?>
        <div class="login-alert-box">
            <p>Szeretnél te is képet feltölteni? <a href="index.php?belepes">Jelentkezz be</a>!</p>
        </div>
    <?php endif; ?>

    <div class="gallery-grid">
    <?php if (empty($kepek)): ?>
        <p class="empty-msg">Még nincs kép a galériában.</p>
    <?php else: ?>
        <?php foreach ($kepek as $kep): ?>
            <div class="gallery-item">
                <div class="image-container">
                    <img src="<?= $kep ?>" alt="Galéria kép" onclick="openLightbox(this.src)">
                    
                    <?php if (isset($_SESSION['login'])): ?>
                        <a href="index.php?kepek&torles=<?= basename($kep) ?>" 
                           class="delete-overlay-btn" 
                           title="Kép törlése"
                           onclick="return confirm('Biztosan törölni szeretnéd ezt a képet?')">
                           <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                        </a>
                        <?php endif; ?>
                    </div>
                
                    <div class="img-info">
                        <span><?= basename($kep) ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div id="lightbox" class="lightbox" onclick="closeLightbox()">
    <span class="close-btn">&times;</span>
    <img class="lightbox-content" id="lightbox-img">
    </div>

</section>

<script>
function updateFileName() {
    const input = document.getElementById('fileInput');
    const display = document.getElementById('file-name-display');
    if (input.files.length > 0) {
        display.textContent = "Kiválasztva: " + input.files[0].name;
        display.style.color = "#38bdf8";
    }
}

function openLightbox(src) {
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    
    lightboxImg.src = src;
    lightbox.style.display = 'flex';
    document.body.style.overflow = 'hidden'; 
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    lightbox.style.display = 'none';
    document.body.style.overflow = 'auto';
}

document.querySelector('.lightbox-content').addEventListener('click', function(e) {
    e.stopPropagation();
});
</script>