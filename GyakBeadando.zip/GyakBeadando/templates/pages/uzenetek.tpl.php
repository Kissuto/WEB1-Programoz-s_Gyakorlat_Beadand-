<div class="auth-card" style="max-width: 900px; margin: 0 auto;">
    <h2>Beérkezett üzenetek</h2>
    <?php if (isset($uzenetek_lista) && count($uzenetek_lista) > 0): ?>
        <table style="width: 100%; border-collapse: collapse; color: var(--text-main); margin-top: 20px;">
            <tr style="border-bottom: 2px solid var(--primary-color); text-align: left;">
                <th style="padding: 10px;">Küldő / Azonosító</th>
                <th style="padding: 10px;">Időpont</th>
                <th style="padding: 10px;">Üzenet</th>
            </tr>
            <?php foreach ($uzenetek_lista as $u): ?>
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.1);">
                    <td style="padding: 10px;">
                        <strong><?= htmlspecialchars($u['nev']) ?></strong><br>
                        <small>(<?= htmlspecialchars($u['bejelentkezes']) ?>)</small>
                    </td>
                    <td style="padding: 10px; font-size: 0.85rem;"><?= $u['datum'] ?></td>
                    <td style="padding: 10px;"><?= nl2br(htmlspecialchars($u['szoveg'])) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p style="text-align: center; padding: 20px;">Még nem érkezett üzenet.</p>
    <?php endif; ?>
</div>