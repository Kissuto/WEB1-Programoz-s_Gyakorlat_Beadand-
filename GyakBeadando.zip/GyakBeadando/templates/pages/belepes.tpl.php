<div class="auth-container">
    <div class="auth-card">
        <h2>Bejelentkezés</h2>
        
       <form action="index.php?belepes" method="post">
            <div class="form-group">
                <label for="felhasznalo">Felhasználónév:</label>
                <input type="text" id="felhasznalo" name="felhasznalo" placeholder="felhasznalonev" required>
            </div>
            
            <div class="form-group">
                <label for="jelszo">Jelszó:</label>
                <input type="password" id="jelszo" name="jelszo" placeholder="******" required>
            </div>
            
            <input type="submit" value="Belépés" class="btn">
        </form>

        <?php if(isset($errormessage)): ?>
            <p class="error-msg" style="color: #f43f5e; margin-top: 15px; font-weight: bold;">
                <?= $errormessage ?>
            </p>
        <?php endif; ?>

        <div class="auth-footer" style="margin-top: 25px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center;">
            <p>Még nincs fiókja? 
                <a href="index.php?regisztracio" style="color: #2563eb; font-weight: bold; text-decoration: none;">
                    Regisztráljon itt!
                </a>
            </p>
        </div>
    </div>
</div>