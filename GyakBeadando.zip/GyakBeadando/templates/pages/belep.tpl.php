<div class="auth-result">
    <?php if(isset($errormessage)): ?>
        <h2 style="color: #d32f2f;">Sikertelen bejelentkezés</h2>
        <p><?= $errormessage ?></p>
        <br>
        <a href="index.php?belepes" class="btn">Próbálja újra</a>
        
    <?php elseif(isset($uzenet)): ?>
        <h2 style="color: #2e7d32;">Sikeres bejelentkezés!</h2>
        <p><?= $uzenet ?></p>
        <p>Most már elérheti a korlátozott funkciókat, például a képfeltöltést.</p>
        <br>
        <a href="index.php" class="btn">Ugrás a főoldalra</a>
        
    <?php else: ?>
        <script>window.location.href = "index.php?belepes";</script>
    <?php endif; ?>
</div>